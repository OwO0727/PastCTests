// plist: convenience module to make creating linked lists of people easier

extern list make_plist( void );
